class SparkParams:
    def __init__(self, args):
        self.args = args